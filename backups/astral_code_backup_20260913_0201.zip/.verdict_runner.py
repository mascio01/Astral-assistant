﻿import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\masci\Astral')
import os
os.chdir(r'C:\Users\masci\Astral')
from verdict.verdict import run_verdict
run_verdict(open('.verdict_quesito.tmp', encoding='utf-8-sig').read())
print('VERDICT_DONE')
